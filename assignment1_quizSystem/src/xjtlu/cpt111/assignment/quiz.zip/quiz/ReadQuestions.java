package xjtlu.cpt111.assignment.quiz;

import xjtlu.cpt111.assignment.quiz.model.Question;
import xjtlu.cpt111.assignment.quiz.util.IOUtilities;

import java.util.List;
import java.util.ArrayList;  // 导入 ArrayList 类

public class ReadQuestions {

	private static final String RESOURCES_PATH = "src/main/resources/";
	private static final String QUESTIONS_BANK_PATH = "resources/questionsBank/";

	public static void loadQuestions(List<Question> allQuestions) {
		String filename = QUESTIONS_BANK_PATH;

		try {
			Question[] questions = IOUtilities.readQuestions(filename);
			if (questions != null && questions.length > 0) {
				for (Question question : questions) {
					allQuestions.add(question);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// main 方法测试加载问题
	public static void main(String... arguments) {
		List<Question> allQuestions = new ArrayList<>();
		loadQuestions(allQuestions);
		if (allQuestions.isEmpty()) {
			System.out.println("No questions loaded.");
		}
	}
}
