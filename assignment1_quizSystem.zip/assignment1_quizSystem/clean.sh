#!/bin/sh


REPOSITORY=../repositories/maven
GROUP_XJTLU=xjtlu/cpt111

SOURCE_PATH=src
DESTINATION_PATH=build


rm -fr "${DESTINATION_PATH}"

