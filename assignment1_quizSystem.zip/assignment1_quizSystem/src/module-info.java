/**
 * CPT111 Laboratory: Complexity Analysis
 */
module xjtlu.cpt111.assignment.quiz {
	exports xjtlu.cpt111.assignment.quiz;
    exports xjtlu.cpt111.assignment;
    requires xjtlu.cpt111.assignment.quiz.lib;
}
